# Municipal Digital Services Portal — homepage prototype

A Vite + React + Tailwind CSS prototype of a municipal government digital
services portal homepage. All data shown (offices, announcements, events,
stats) is placeholder demo content.

## Setup

```bash
npm install
npm run dev
```

Then open the URL Vite prints (defaults to http://localhost:5173).

## Build for production

```bash
npm run build
npm run preview
```

## Stack

- [Vite](https://vitejs.dev/) — build tool and dev server
- [React 18](https://react.dev/)
- [Tailwind CSS](https://tailwindcss.com/) — utility classes
- [lucide-react](https://lucide.dev/) — icon set

## Brand palette

| Role       | Hex       |
|------------|-----------|
| Primary    | `#0F4C81` |
| Background | `#FFFFFF` |
| Accent     | `#D4AF37` |

## Project structure

```
municipal-portal/
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
└── src/
    ├── main.jsx
    ├── App.jsx      # homepage component
    └── index.css    # Tailwind directives
```
